import './static/docs/assets/css/global.css';
