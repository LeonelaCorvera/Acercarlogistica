import React from 'react';
import { SearchControlOptions } from '../../dist/SearchControl';

export const SearchControl: React.SFC<SearchControlOptions> = () => <div />;
